# Base documentaire RH – pack prêt à publier

## Contenu
- `index.html` : page d'accueil et moteur de recherche
- `fiches/conge-supplementaire-naissance.html` : première fiche
- `assets/style.css` : styles
- `assets/app.js` : recherche et filtres
- `_redirects` : configuration Netlify
- `netlify.toml` : configuration Netlify
- `vercel.json` : configuration Vercel
- `README.md` : ce fichier

## Publication rapide avec Netlify
1. Créer un compte sur Netlify.
2. Depuis le tableau de bord, choisir l'option de déploiement manuel / glisser-déposer.
3. Déposer le dossier `site-rh-pack` (ou son contenu décompressé).
4. Netlify génère une adresse publique en `netlify.app`.
5. Cette adresse pourra ensuite être personnalisée avec un nom de domaine.

## Publication avec GitHub Pages
1. Créer un dépôt GitHub.
2. Ajouter tous les fichiers du dossier.
3. Activer GitHub Pages dans les paramètres du dépôt.
4. Choisir la branche contenant `index.html`.

## Ajouter une nouvelle fiche
- Créer un nouveau fichier HTML dans `fiches/`.
- Ajouter une carte dans `index.html`.
- Ajouter la catégorie et les mots-clés dans l'attribut `data-search`.
- Le moteur de recherche fonctionnera automatiquement.

## Évolution prévue
La structure est volontairement simple pour permettre ensuite :
- une recherche plus avancée ;
- des catégories et sous-catégories ;
- des filtres par date ;
- une page dédiée à chaque fiche ;
- un espace « nouveautés » ;
- une identité visuelle personnalisée ;
- l'ajout progressif de toutes les fiches PDF.
