const search = document.getElementById('search');
const cards = [...document.querySelectorAll('.card')];
const buttons = [...document.querySelectorAll('.category')];
const empty = document.getElementById('empty');
const count = document.getElementById('result-count');
let category = 'all';

function filter() {
  const q = search.value.toLowerCase().trim();
  let visible = 0;
  cards.forEach(card => {
    const okCat = category === 'all' || card.dataset.category === category;
    const okText = !q || card.dataset.search.toLowerCase().includes(q) || card.innerText.toLowerCase().includes(q);
    card.hidden = !(okCat && okText);
    if (!card.hidden) visible++;
  });
  count.textContent = `${visible} fiche${visible > 1 ? 's' : ''}`;
  empty.hidden = visible !== 0;
}
search.addEventListener('input', filter);
buttons.forEach(btn => btn.addEventListener('click', () => {
  buttons.forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  category = btn.dataset.category;
  filter();
}));
